<form class="search" action="<?php echo esc_url( home_url( '/' ) ) . "search/"; ?>">
	<fieldset>
    	<input name="key" type="text" value="Search"/>
        <button type="submit" class="search_submit" ></button>
    </fieldset>
</form>
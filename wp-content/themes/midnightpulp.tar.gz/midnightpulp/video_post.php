<?php get_header();?>

<?php query_posts( array(
            'post_type' => 'movie',
            'taxonomy' => 'movie_genre',
            'term' => 'hulu',
            'posts_per_page' => 25 
        )); ?>
        <?php if(have_posts()): ?>
        <?php while(have_posts()):the_post(); ?>
		
        <?php $post->post_content?>
        
         <?php endwhile; else: ?>
         
        <p>Sorry No item</p>
         
        <?php endif; ?>
        <?php wp_reset_query(); ?>
        
        <?php get_footer();?>
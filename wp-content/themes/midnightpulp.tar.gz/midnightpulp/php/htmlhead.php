<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<title>Asian Crush Front Page</title>

  
<!--<link rel="stylesheet" href="stylesheets/ac-cpbootstrap-backup.css">-->

  <link href='<?php echo PfBase::app()->themeUrl; ?>/_css/ac-cpbootstrap-backup.css' rel='stylesheet' type='text/css' />
 
 
<!--<link rel="stylesheet" href="stylesheets/frontpage.css">-->


  <link href='<?php echo PfBase::app()->themeUrl; ?>/_css/frontpage.css' rel='stylesheet' type='text/css' />
 

 <!--<script src="javascripts/vendor/custom.modernizr.js"></script>-->


  <script src="<?php echo PfBase::app()->themeUrl; ?>/_js/vendor/custom.modernizr.js" type="text/javascript"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>

  
  

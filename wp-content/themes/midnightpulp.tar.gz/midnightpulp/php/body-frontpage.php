	<div id="tabrow">
		<div class="navish selected" id="tab1">ALL</div>
		<div class="navish" id="tab2">NEWSFEED</div>
		<div class="navish" id="tab3">COLUMNS</div>
		<div class="navish" id="tab4">MOVIES</div>
	</div>

	<div class="clearfix" id="tilewrapper">

		<div id="that_one_line_at_the_top">
			&nbsp;<hr/>&nbsp;
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_1.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_1.png"></div>
			<div class="headline headlinefont">A Film Bizarre Beyond Belief: Praise Zardoz!</div>
			<div class="text">Movies like Zardoz encounter a specific pitfall: they appear so weird on the surface that digging any further seems fruitless. This is a BIG mistake.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_2.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_2.png"></div>
			<div class="headline headlinefont">Killer Mushrooms on the Dark Side of the Sun</div>
			<div class="text">John Zorn's Dark Side of the Sun film series continues at the Japan Society with a screening of Matango (aka Attack of the Killer Mushrooms).</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>


		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_3.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_3.png"></div>
			<div class="headline headlinefont">Join artist Paul Batt to reflect on the influences of Alex Prager.</div>
			<div class="text">Paul Batt is a graduate of both the Victorian College of the Arts (VCA) and Royal Melbourne Institute of Technology (RMIT)</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_4.png"></div>-->
			<div class="image"><img src="<?php echo Pfbase::app()->themeUrl; ?>/_assets/images/news_post_4.png"></div>
			<div class="headline headlinefont">How Tim and Eric Carved a Niche in Cathode Ray Hell</div>
			<div class="text">Love them or hate them, at some point in time Tim and Eric have probably made you queasy.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_5.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_5.png"></div>
			<div class="headline headlinefont">Facebook Pulp: The Cult of CHARLIE CASANOVA</div>
			<div class="text">CHARLIE CASANOVA was assembled on Facebook. Learn the backstory of this chilling slice of Midnight Pulp.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_6.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_6.png"></div>
			<div class="headline headlinefont">Sweetly Sleazy: Pink Film at NYC's Japan Society</div>
			<div class="text">Bondage, torture, and violence are all common themes in Japanese pink films, making this delightful story an even sweeter surprise than you might expect.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_7.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_7.png"></div>
			<div class="headline headlinefont">Giallo’s Tangled Family Tree of Death and Debauchery</div>
			<div class="text">Discover the glorious, gory world of Giallo, one of the greatest genres in pulp film history.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_8.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_8.png"></div>
			<div class="headline headlinefont">Long Live the Hollywood Flesh: Cronenberg Meets Tinseltown</div>
			<div class="text">Cronenberg has made some of the most disturbing and cerebral pulp films ever known to midnight moviegoers. Now he's taking on Hollywood with MAPS TO THE STARS.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<!--<div class="image"><img src="assets/images/news_post_9.png"></div>-->
			<div class="image"><img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/news_post_9.png"></div>
     		<div class="headline headlinefont">Is The Scream Porn Parody a Legitimately Good Movie?</div>
			<div class="text">Eli Cross joins us for an EXCLUSIVE interview to finally lay to rest nagging uncertainties, and lay bare the story behind the making of his only porn parody.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<br /><br /><br />
		<br /><br /><br />

		
	</div>

<div id="copyrightwrapper">
	<img src="<?php echo PfBase::app()->themeUrl; ?>/_assets/images/ac-logo.png"  />
	<div id="copyrightspan">Copyright © 2011 - 2015 by Digital Media Rights. All Rights Reserved</div>
</div>	
<div class="footcolumn colspan-3-12">
<span class="footcolhead">Navigate</span><br/> <br />
	
		<span class="footcolitem">MOVIES</span><br />
		<span class="footcolitem">SPORTS</span><br />
		<span class="footcolitem">FIND ASIAN CRUSH</span><br />
		<span class="footcolitem">ABOUT</span><br />
		<span class="footcolitem">JOBS</span><br />
	
</div>

<div class="footcolumn colspan-3-12">
<span class="footcolhead">Asian Crush</span><br/> <br />
	
		<span class="footcolitem">PRIVACY POLICY</span><br />
		<span class="footcolitem">TERMS AND CONDITIONS</span><br />
		<span class="footcolitem">JOBS</span><br />
	
</div>

<div class="footcolumn colspan-5-12">
<span class="footcolhead">How To</span><br/> <br />
	
		<span class="footcolitem">JOIN OUR MAILING LIST</span><br />
		<span class="footcolitem">SUBMIT YOUR FILM or PROGRAM</span><br />
		<span class="footcolitem">ADVERTISE WITH US</span><br />
		<span class="footcolitem">CONTACT US</span><br />
	
</div>
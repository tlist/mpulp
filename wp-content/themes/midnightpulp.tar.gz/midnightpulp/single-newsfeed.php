<?php get_header() ?>
<?php 
/**	
 *	SETUP DATA FOR A NEWSFEED
 * $arr_newsfeed_director
 * $arr_newfeed_actor_actress
 * $arr_newsfeed_region
 * $newsfeed_duration
 * $mewsfeed_featured ?
 * $newsfeed_plot
 * $newsfeed_quotes
 * $newsfeed_embedded_video
 * $newsfeed_tills	
  */
$newsfeed_terms = wp_get_object_terms(get_the_ID(), array('newsfeed_director', 'newsfeed_actor_actress', 'newsfeed_region', 'newsfeed_genre') );

$arr_newsfeed_genre = $arr_newsfeed_director = $arr_newsfeed_actor_actress = $arr_newsfeed_region = array();
foreach ($newsfeed_terms as $newsfeed_term) {
	switch ( $newsfeed_term->taxonomy ) {
		case 'newsfeed_director':
			$arr_newsfeed_director[] =  $newsfeed_term->name;
			break;
		case 'newsfeed_actor_actress':
			$arr_newsfeed_actor_actress[] =  $newsfeed_term->name;
			break;
		case 'newsfeed_region':
			$arr_newsfeed_region[] =  $newsfeed_term->name;
			break;		
		case 'newsfeed_genre':
			$arr_newsfeed_genre[] =  $newsfeed_term->name;
			break;				
	}
}

//echo "retrieving metadata for news column";
$all_meta_data = amr_get_post_meta_all(get_the_ID());
//var_dump($all_meta_data);
$newsfeed_year 			= $all_meta_data['newsfeed_year'] ? ' ('. $all_meta_data['newsfeed_year'] . ')' : '';
$newsfeed_duration 		= $all_meta_data['newsfeed_duration'];
$newsfeed_featured 		= $all_meta_data['newsfeed_featured'];
$newsfeed_quote				= $all_meta_data['newsfeed_quote'];
$newsfeed_quotes			= $all_meta_data['newsfeed_quotes'];
$newsfeed_embedded_video 	= $all_meta_data['newsfeed_embedded_video'];

$newsfeed_hulu_video 		= $all_meta_data['newsfeed_hulu_video'];
$newsfeed_amazon_link 		= $all_meta_data['newsfeed_amazon_link'];
$newsfeed_thumb			= $all_meta_data['_thumbnail_id'];

$args = array(
   'post_type' 	=> 'attachment',
   'orderby'   	=> 'menu_order',
   'order'	 	=> 	"ASC",
   'numberposts' => -1,
   'post_parent' => $post->ID,
   'exclude'	 => implode(', ', array($newsfeed_thumb)) 
  );

  
  
 $strAuthorNiceName	=	get_the_author_meta('user_nicename', $post->post_author);
		
 $date = strtotime($post->post_date);
 $formatted_date = date('m/d/Y', $date);
		 
		 
  
$newsfeed_tills = array();

$attachments = get_posts( $args );
     if ( $attachments ) {
        foreach ( $attachments as $attachment ) {
           		$newsfeed_tills[] = wp_get_attachment_image( $attachment->ID, 'newsfeed_still');
      }
}

?>
<div class="main_content newsfeed_item">
	
	<div class="article left_column">
		<div class="blog_banner">
			<?php the_post_thumbnail('newsfeed_banner', array('alt' => get_the_title(), 'title' => get_the_title(), 'class' => 'thumbnail'));?>
		</div> <!-- blog banner -->
	
    <span class="tag_sharp_edges">NEWS</span>
		<h1><?php echo get_the_title() ?></h1>
		<span class="author">by <?php echo $strAuthorNiceName;?> </span><span class="date"><?php echo $formatted_date;?></span>
          
        <div class="genre">
		      <?php 
				    foreach($arr_newsfeed_genre as $genre) 
				       {
				           
		                echo '<a href="'. get_bloginfo("url").'/movie_genre/'.$genre.'">'.$genre.'</a>';
				    }
		      ?>
        
      	
		</div>
        <?php if ($post->post_content) { ?>
				    	<?php 
				        $content = apply_filters('the_content', $post->post_content);
				        $content = str_replace(']]>', ']]&gt;', $content);
				        echo $content; ?>
		<?php } ?>
      
        <?php if ($newsfeed_quote) { ?>
			<p><?php echo nl2br($newsfeed_quote); ?></p>
        <?php } ?>
		
		<?php if ($newsfeed_hulu_video) { 
        echo "<div class=\"movie_hulu_video\">" . $newsfeed_hulu_video ."</div>";
		} ?>
        
        <?php if($newsfeed_embedded_video) {
        	echo wp_oembed_get( $newsfeed_embedded_video );
        }?>
      	  

    </div> <!-- End Left Column -->
	
      <div class="related_stuff_wrapper right_column">
            <div class="related_stuff_box">
			<span class="tag_sharp_edges">Elsewhere, On Asian Crush</span>
			
			<!-- loop through related news stories -->
    
	
	
	
			  <?php
			
	             $arg = array (
				                'post_status' => 'publish',
				                'post_type' => 'newsfeed',
				                'numberposts' => 12,
				                'orderby' => 'asc'
				                );
               
               $news_posts = get_posts($arg ); 
              
               if($news_posts):
             
               ?>
               
               	<ul>
               
               <?php 
             
               foreach($news_posts as $news_post): 
               $thumbnail = get_the_post_thumbnail($news_post->ID,"newsfeed_thumb",true);
          
            
               ?>
               
               

           <li>
           <a href= "<?php echo get_permalink($news_post->ID); ?>" >
           <div class="thumbnail-wrapper"><?php echo $thumbnail;?></div> 
           <span><?php echo $news_post->post_title; ?></span>

           </a>
           </li>
		   <!--<div class="separator"></div> -->
				
			       
       	             <?php endforeach; ?>
		
         <?php endif; ?>			       
			
			   </ul>
			</div><!--end related stuff wrapper-->
        </div><!-- end right column--> 
	

            <div class="share">
                <!-- AddThis Button BEGIN -->
                <div class="addthis_toolbox addthis_default_style ">
                <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
                <a class="addthis_button_tweet"></a>
                <a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
                <a class="addthis_counter addthis_pill_style"></a>
                </div>
                <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4e65e86d3cdebecf"></script>
                <!-- AddThis Button END -->			
            </div> <!-- end share -->
    
	    <div class="disqus_slot">
            <?php comments_template(); ?>
        </div>
</div> <!--- main content -->


	
		<div class="clearfix">&nbsp;</div>
    
<?php get_footer() ?>


<div id="footer">
	<br><br><br><br>
	<div class="separator"></div>
	<div class="footer-sidebar">
        <?php dynamic_sidebar ('footer-1st');?>
		<?php dynamic_sidebar('footer-2nd'); ?>
		<?php dynamic_sidebar('footer-3rd'); ?>
	</div>
						    
						   
	<br clear="all" />
	<div id="footer-bar">
		<div id="copyrightwrapper">
	  		<img src="<?php echo PfBase::app()->themeUrl; ?>/_img/asiancrushlogo_icon.png" alt="<?php bloginfo('name'); ?>" />
			<span id="copyrightspan">
			    <p>&copy; <?php echo date('Y') ?> by Digital Media Rights. All Rights Reserved.</p>
			</span>
		</div>
	</div>	
</div>
				

        </div> <!-- end body_container -->
	</div>
	<!--	/Browser	-->
	
</div>
<!--	/Device Platform	-->
		
	</body>
</html>

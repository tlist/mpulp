<?php
/**
 * Template Name: Page Playlist
 */

?>
 
<?php get_header() ?>
	<div class="main_content watchNow">
	
		    <?php 
		          query_posts( array(
            'post_type' => 'playlist',
            'posts_per_page' =>  -1 
        )); 
        
        ?>	
	     
        <?php if(have_posts()): ?>
        
            <?php
            $count = 1;
            while(have_posts()):the_post(); ?>
    		              
                <h1><?php echo get_the_title(); ?></h1>
     
                <?php $posts = get_field('related_movies');?>
     
                <?php if ($posts) : ?>
                   
                    <ul id="mycarousel<?php echo $count;  ?>" class="jcarousel-skin-tango owl-carousel">
                    
                    <?php foreach($posts as $post) : ?>
                    
                    
                    <li>
                        <a href="<?php the_permalink(); ?>">
                            <span class="top-movie-thumb css-hover2">
                                <?php the_post_thumbnail('top-thumb');?>
                            </span>
                            <span class="top-movie-title">
                                <span><?php echo get_the_title($post->ID); ?></span>
                            </span>
                        </a>
                    </li>
                    
                    <?php endforeach; ?>
                    
                    </ul>
                    
                    <div class="slide_nav" id="slide_nav<?php echo $count;  ?>">
                        <div class="fir homeslide_arrow left_arrow">&lt;</div>
                        <div class="fir homeslide_arrow right_arrow">&gt;</div>
                    </div>
                <?php endif; ?>
                
            <?php $count++; ?>
            <?php endwhile;?>
        
        <?php endif; ?>
    

</div>	  

<script type="text/javascript">
jQuery(document).ready(function(){

    var count = <?php echo $count ?>;
    for (i = 1; i < count; i++) {
        console.log(i);
    }

	var masthead = jQuery("#mycarousel<?php echo ($count - 4); ?>");
	
	masthead.owlCarousel({
        responsive: {
            0 : {
        		items: 1,
        		loop: true,
            },
        
            440 : {
        		items: 2,
        		loop: true,
            },
            
            680 : {
        		items: 3,
        		loop: true,
            },
            
           910 : {
        		items: 4,
        		loop: true,
            },
        
            1200 : {
        		items: 5,
        		loop: true,
            }   
        }
	});
	
	jQuery(".right_arrow").click(function(){
		masthead.trigger('next.owl.carousel');
	});
	
	jQuery(".left_arrow").click(function(){
		masthead.trigger('prev.owl.carousel');
	});
	
    jQuery(".left_arrow").hover(function(event) {
        jQuery(".left_cheat").toggleClass("active");
    });
    jQuery(".right_arrow").hover(function(event) {
        jQuery(".right_cheat").toggleClass("active");
    });
});
    
</script>

<style>
    .slide_nav {position:absolute; width:96%; margin:-22% 2% 0; z-index:90;  text-indent:0;}
    .homeslide_arrow {background:blue; display:inline-block; color:#fff; text-indent:0; font-size:2.0rem; cursor:pointer;}
    .homeslide_arrow.right_arrow {float:right;}
    .homeslide_arrow.left_arrow {float:left;}
</style>
<?php get_footer() ?>

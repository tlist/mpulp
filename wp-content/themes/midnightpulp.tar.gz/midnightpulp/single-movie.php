<?php get_header() ?>
<?php 
/**	
 *	SETUP DATA FOR A MOVIE
 * $arr_movie_director
 * $arr_movie_actor_actress
 * $arr_movie_region
 * $movie_duration
 * $movie_featured ?
 * $movie_plot
 * $movie_quotes
 * $movie_embedded_video
 * $movie_tills	
  */
$movie_terms = wp_get_object_terms(get_the_ID(), array('movie_director', 'movie_actor_actress', 'movie_region', 'movie_genre') );


$arr_movie_genre = $arr_movie_director = $arr_movie_actor_actress = $arr_movie_region = array();
foreach ($movie_terms as $movie_term) {
    switch ( $movie_term->taxonomy ) {
		case 'movie_director':
			$arr_movie_director[] =  $movie_term->name;
			$arr_movie_director_slug[] = $movie_term->slug;
			break;
		case 'movie_actor_actress':
			$arr_movie_actor_actress[] =  $movie_term->name;
			$arr_movie_actor_actress_slug[] = $movie_term->slug;
			break;
		case 'movie_region':
			$arr_movie_region[] =  $movie_term->name;
			break;		
		case 'movie_genre':
			$arr_movie_genre[] =  $movie_term->name;
			break;				
	}
}




$all_meta_data = amr_get_post_meta_all(get_the_ID());

$movie_year 			= $all_meta_data['movie_year'] ? ' ('. $all_meta_data['movie_year'] . ')' : '';
$movie_duration 		= $all_meta_data['movie_duration'];
$movie_featured 		= $all_meta_data['movie_featured'];
$movie_plot				= $all_meta_data['movie_plot'];
$movie_quotes			= $all_meta_data['movie_quotes'];
$movie_embedded_video 	= $all_meta_data['movie_embedded_video'];
$movie_hulu_video 		= $all_meta_data['movie_hulu_video'];
$movie_amazon_link 		= $all_meta_data['movie_amazon_link'];
$movie_google_link      = $all_meta_data['movie_google_link'];
$movie_misc_link        = $all_meta_data['movie_misc_link'];
$movie_vimeo_link       = $all_meta_data['movie_vimeo_link'];
$movie_thumb			= $all_meta_data['_thumbnail_id'];

$args = array(
   'post_type' 	=> 'attachment',
   'orderby'   	=> 'menu_order',
   'order'	 	=> 	"ASC",
   'numberposts' => -1,
   'post_parent' => $post->ID,
   'exclude'	 => implode(', ', array($movie_thumb)) 
  );
$movie_tills = array();

$attachments = get_posts( $args );
     if ( $attachments ) {
        foreach ( $attachments as $attachment ) {
           		$movie_tills[] = wp_get_attachment_image( $attachment->ID, 'movie_still');
      }
}
	 
//echo '<pre>';	 
//var_dump($movie_terms);
//var_dump($arr_movie_director);
//var_dump($arr_movie_actor_actress);
//var_dump($arr_movie_region);
//var_dump($all_meta_data);
//var_dump($movie_duration);
//var_dump($movie_feature);
//var_dump($movie_plot);
//var_dump($movie_quotes);
//var_dump($movie_embedded_video);
//var_dump ($movie_tills);
//echo '</pre>';



?>
	
    	
    
    <?php if ($movie_hulu_video) { 
        echo "<div class=\"movie_hulu_video\"><div class=\"center_frame\">" . $movie_hulu_video ."</div></div>";
	} else {
	    echo "<div class=\"movie_hulu_video\" style=\"color:#fff; font-size:300%; margin:0 auto; padding: 3em 1em; height:auto; width:1100px; \">WE'RE STILL WORKING ON GETTING OUR ENTIRE CATALOG ONLINE, SO JOIN THE MAILING LIST TO GET THE LATEST NEWS AS WE CONTINUE UPDATING OUR LIBRARY</div>";
	}
	
	
	?>

    
	<div class="main_content single-movie">
        <h1 class="movie-title"><?php echo get_the_title() ?></h1>
        <span class="country"><?php echo implode(', ',$arr_movie_region);?>
        </span> <span class="year"><?php echo $movie_year;?>&nbsp;</span>
            <?php if ($movie_duration) { ?>
                <span class="time">-&nbsp<?php echo $movie_duration; ?></span>
            <?php } ?>
        <div class="pull_quote">
       		<?php if ($post->post_content) { ?>

			    	<?php 
			        $content = apply_filters('the_content', $post->post_content);
			        $content = str_replace(']]>', ']]&gt;', $content);
			        echo $content; ?>

		    <?php } ?>
        </div>
        <div class="wrapper movie_profile group left_column">
        	<!--Made content of movie profile hidden to try and restyle wrapper as a table-->
        	<table>
        		<tr class="row1">
        			<th style="width:66%;font-size:160%;">SYNOPSIs</th>
        			<th>Director</th>
        		</tr>
        		<tr class="row2">
        		<td rowspan="4">
	    			<?php if ($movie_plot) { ?>
						<p><?php echo nl2br($movie_plot); ?></p>
	                <?php } ?>	
				</td>
        			<td>
 	                  <?php 
				            $count=0;
				            foreach($arr_movie_director as $director) 
				               {
				           
		                           echo '<a href="'. get_bloginfo("url").'/movie_director/'.$arr_movie_director_slug[$count].'">'.$director.'</a>';
				                   $count++;
				               }
		              ?>
        			</td>
        		</tr>
        		<tr class="row3">
        			<th>Cast</th>
        		</tr>
	       		<tr class="row4">
        			<td>
        		  <?php 
        		         $count=0;
				         foreach($arr_movie_actor_actress as $actor) 
				               {
				                echo '<a href="'. get_bloginfo("url").'/movie_actor_actress/'.$arr_movie_actor_actress_slug[$count].'">'.$actor.'</a>';
				                $count++;
				            }
		              ?>
                    </td>
        		</tr>
          		<tr class="row5">
     				<?php 
				       foreach($arr_movie_genre as $genre) 
				       {
				        echo '<a href="'. get_bloginfo("url").'/movie_genre/'.$genre.'">'.$genre.'</a>';
				       }
		             ?>
        		</tr>
        	</table>
        	
		
		 	
			
	        <!--<?php if ($movie_amazon_link) { ?>-->
         <!--       <a href="<?php echo $movie_amazon_link ?>" class="buy fromAmazon" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/amazon-icon-64x64.png" alt="BuyDVD on Amazon | <?php bloginfo('name'); ?>"/></a>-->
         <!--   <?php } ?>-->
         <!--    <?php if ($movie_google_link) { ?>-->
         <!--       <a href="<?php echo $movie_google_link ?>" class="buy fromGoogle" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/googlePlay-icon-64x64.png" alt="BuyDVD on Google Play | <?php bloginfo('name'); ?>"/></a>-->
         <!--   <?php } ?>-->
         <!--    <?php if ($movie_vimeo_link) { ?>-->
         <!--       <a href="<?php echo $movie_vimeo_link ?>" class="buy fromVimeo" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/vimeo-icon-64x64.png" alt="BuyDVD on Vimeo | <?php bloginfo('name'); ?>"/></a>-->
         <!--   <?php } ?>-->
         <!--     <?php if ($movie_misc_link) { ?>-->
	        <!--        <a href="<?php echo $movie_misc_link ?>" class="buy fromMisc" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/misc-icon-64x64.png" alt="Buy | <?php bloginfo('name'); ?>"/></a>-->
         <!--   <?php } ?>-->
            
			<div class="own-it optional_meta">
				<h3>Own It Now</h3>
				            
					<a <?php echo $movie_amazon_link ? 'href="' . $movie_amazon_link . '"' : '' ?> class="buy fromAmazon <?php echo $movie_amazon_link ? 'available' : '' ?>" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/amazon-icon-64x64.png" alt="BuyDVD on Amazon | <?php bloginfo('name'); ?>"/></a>
					<a <?php echo $movie_google_link ? 'href="' . $movie_google_link . '"' : '' ?> class="buy fromGoogle <?php echo $movie_google_link ? 'available' : '' ?>" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/googlePlay-icon-64x64.png" alt="BuyDVD on Google Play | <?php bloginfo('name'); ?>"/></a>
					<a <?php echo $movie_vimeo_link ? 'href="' . $movie_vimeo_link . '"' : '' ?> class="buy fromVimeo <?php echo $movie_vimeo_link ? 'available' : '' ?>" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/vimeo-icon-64x64.png" alt="BuyDVD on Vimeo | <?php bloginfo('name'); ?>"/></a>
					<a <?php echo $movie_misc_link ? 'href="' . $movie_misc_link . '"' : '' ?> class="buy fromMisc <?php echo $movie_misc_link ? 'available' : '' ?>" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/misc-icon-64x64.png" alt="Buy | <?php bloginfo('name'); ?>"/></a>
				
			</div>

            
            <?php if ($movie_embedded_video) { ?>
                <div class="optional_meta" id="trailer">
                <h3 onclick="toggleTrailer()">TRAILER</h3>
                <?php echo $movie_embedded_video; ?>
                </div>
			<?php } ?>

			<script>
			function toggleTrailer() {
			    var trailer = document.getElementById("trailer");
			    if (trailer.className == "optional_meta") {trailer.className = "optional_meta active";}else{trailer.className = "optional_meta";}
			}
			</script>
			
            <br clear="all">
            <div class="share">
                <!-- AddThis Button BEGIN -->
                <div class="addthis_toolbox addthis_default_style ">
                <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
                <a class="addthis_button_tweet"></a>
                <a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
                <a class="addthis_counter addthis_pill_style"></a>
                </div>
                <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4e65e86d3cdebecf"></script>
                <!-- AddThis Button END -->			
            </div>
        	<!--End table-->
              	<div class="cls-featured-image">
            		<?php the_post_thumbnail('medium', array('alt' => get_the_title(), 'title' => get_the_title(), 'class' => 'thumbnail'));?>
            	</div>	
        </div> <!-- end movie profile wrapper -->	   
        

        <div class="related_stuff_wrapper right_column">
            <div class="related_stuff_box">
			<span class="tag_sharp_edges">Newsfeed</span>
			
			
			
			<?php	
			
	             $arg = array (
				                'post_status' => 'publish',
				                'post_type' => 'newsfeed',
				                'numberposts' => 8,
				                'orderby' => 'asc'
				                );
               
               $news_posts = get_posts($arg ); 
              
               if($news_posts):
             
               ?>
               
               	<ul>
               
               <?php 
             
               foreach($news_posts as $news_post): 
               $thumbnail = get_the_post_thumbnail($news_post->ID,"newsfeed_thumb",true);
          
            
               ?>
               
               

           <li>
           <a href= "<?php echo get_permalink($news_post->ID); ?>" >
           <div class="thumbnail-wrapper"><?php echo $thumbnail;?></div> 
           <span><?php echo $news_post->post_title; ?></span>

           </a>
           <div class="clearfix"></div>
           </li>
			       
       	             <?php endforeach; ?>
		
         <?php endif; ?>			       
			
			   </ul>
			</div>
        </div><!--end related stuff wrapper-->
       
        
        <div class="disqus_slot">
           <?php 
           //echo "calling comments template<br>";
           comments_template(); ?>
        </div><!--end disqus_slot-->
    
    <?php 
	$terms = get_the_terms( $post->ID, 'movie_genre' );
	
	
	if($terms){
	?>
	
        <div class="similar clearfix"><span class="tab">Recommended Titles</span></div>
    
        <div class="movie-genre-box clearfix" ><!-- movie-genre-box start Similar  -->
	


	<?php
	/*	
	 foreach ( $terms as $term ) {
             $slug .= "&term=". $term -> slug;
            }
	
	<?php
3
$args = array(
4
    'tax_query' => array(
5
        array(
6
            'taxonomy' => 'people',
7
            'field'    => 'slug',
8
            'terms'    => 'bob',
9
            'operator' => 'IN'
10
        )
11
    )
12
);
13
$query = new WP_Query( $args );

	
	
	
	*/
	$i = 0;
	foreach ( $terms as $term ) {		
			if("hulu" == $term -> slug){
				continue;
			}else if($i == 0){
				$slug = "'".$term -> slug."'";
				$i++;
			} else if($i != 0){
				$slug .= ",'".$term -> slug."'";
				$i++;
			}
	}
		
	$array = explode(",", $slug);
	
	
			$arg = array (
				'post_status' => 'publish',
				'post_type' => 'movie',
				'numberposts' => 15,
				'orderby' => 'rand',
				'tax_query' => array(
					array(
						'taxonomy' => 'movie_genre',
						'field' => 'slug',
						'terms' => $array,
						'operator' => 'AND'
					)
				)	
			);
			
			$tax_posts = get_posts($arg ); if($tax_posts): 
	?>
        <ul id="mycarousel14" class="jcarousel-skin-tango">
			
			<?php foreach($tax_posts as $tax_post): 
			$thumbnail = get_the_post_thumbnail($tax_post->ID,"top-thumb",true);
			?>
				
                <li>
        		<span class="top-movie-thumb css-hover2">
                <a href="<?php echo get_permalink($tax_post->ID); ?>"><?php echo $thumbnail; ?></a>
                </span>
                <span class="top-movie-title">
                <a href="<?php echo get_permalink($tax_post->ID); ?>"><span><?php echo esc_html($tax_post->post_title); ?></span></a>
                </span>
                </li>
			<?php endforeach; ?>
		
        </ul>
        
	<?php endif; ?>
    </ul></div><!-- movie-genre-box end Similar  -->   
  <?php } ?>  

    
    </div>
    
<?php get_footer() ?>
<div id="search_box">
	
	<div class="find">
	<img src="<?php echo PfBase::app()->themeUrl; ?>/_img/h_find.png" alt="Find <?php bloginfo('name'); ?> near you"/>
    	</div>
	<div class="go">
	<a href="<?php echo site_url() ?>/find/"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/bt_go.png" alt="Find <?php bloginfo('name'); ?> near you "class="css-hover" /></a>
	</div>
    	
 
	<div class="follow_us">
    	<h3>FOLLOW US</h3>
        <div class="social">
        	<a href="http://www.twitter.com/asiancrush" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/ic_twitter.png" alt="Twitter | <?php bloginfo('name'); ?>" class="jquery-hover" /></a>
		<a href="http://www.facebook.com/asiancrushfilms" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/ic_facebook.png" alt="Facebook | <?php bloginfo('name'); ?>"  class="jquery-hover" /></a>
        	<a href="http://www.youtube.com/AsianMedia2010" target="_blank"><img src="<?php echo PfBase::app()->themeUrl; ?>/_img/ic_youtube.png" alt="You Tube | <?php bloginfo('name'); ?>"  class="jquery-hover" /></a>
        </div>
    </div>
</div> <!-- end search box -->
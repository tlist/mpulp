<?php get_header() ?>
 
 
     <?php 

        // start by setting up the query
    $query = new WP_Query( array(
        'post_type' => 'playlist',
    ));
   
    // now check if the query has posts and if so, output their content in a services-box div
    if ( $query->have_posts() ) { ?>
        <div class="services-box">
            <?php while ( $query->have_posts() ) : $query->the_post(); ?>
            <div class="service" id="post-<?php the_ID(); ?>" <?php post_class( 'services' ); ?>>
            <div class="service-img"><a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( 'full' ); ?></a></div>
            <h3><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
            
            </div>
            <?php endwhile; ?>
        </div>
    <?php }
    wp_reset_postdata();
   
}
 ?>

    
	<div class="main_content single-movie">
        <h1 class="movie-title"><?php echo get_the_title() ?></h1>
        
        
        

            <br clear="all">
            <div class="share">
                <!-- AddThis Button BEGIN -->
                <div class="addthis_toolbox addthis_default_style ">
                <a class="addthis_button_facebook_like" fb:like:layout="button_count"></a>
                <a class="addthis_button_tweet"></a>
                <a class="addthis_button_google_plusone" g:plusone:size="medium"></a>
                <a class="addthis_counter addthis_pill_style"></a>
                </div>
                <script type="text/javascript" src="http://s7.addthis.com/js/250/addthis_widget.js#pubid=ra-4e65e86d3cdebecf"></script>
                <!-- AddThis Button END -->			
            </div>
        	<!--End table-->
              	<div class="cls-featured-image">
            		<?php the_post_thumbnail('medium', array('alt' => get_the_title(), 'title' => get_the_title(), 'class' => 'thumbnail'));?>
            	</div>	
        </div> <!-- end movie profile wrapper -->	   
        

        <div class="related_stuff_wrapper">
            <div class="related_stuff_box">
			<span class="tag_sharp_edges">Newsfeed</span>
			
			
			
			<?php	
			
	             $arg = array (
				                'post_status' => 'publish',
				                'post_type' => 'newsfeed',
				                'numberposts' => 8,
				                'orderby' => 'asc'
				                );
               
               $news_posts = get_posts($arg ); 
              
               if($news_posts):
             
               ?>
               
               	<ul>
               
               <?php 
             
               foreach($news_posts as $news_post): 
               $thumbnail = get_the_post_thumbnail($news_post->ID,"newsfeed_thumb",true);
          
            
               ?>
               
               

           <li>
           <a href= "<?php echo get_permalink($news_post->ID); ?>" >
           <div class="thumbnail-wrapper"><?php echo $thumbnail;?></div> 
           <span><?php echo $news_post->post_title; ?></span>

           </a>
           <div class="clearfix"></div>
           </li>
		   <div class="separator"></div> 
				
			       
       	             <?php endforeach; ?>
		
         <?php endif; ?>			       
			
			   </ul>
			</div>
        </div><!--end related stuff wrapper-->
       
        
        <div class="disqus_slot">
           <?php comments_template(); ?>
        </div><!--end disqus_slot-->
    
    <?php 
	$terms = get_the_terms( $post->ID, 'movie_genre' );
	
	
	if($terms){
	?>
	
        <div class="similar clearfix"><span class="tab">Recommended Titles</span></div>
    
        <div class="movie-genre-box clearfix" ><!-- movie-genre-box start Similar  -->
	


	<?php
	/*	
	 foreach ( $terms as $term ) {
             $slug .= "&term=". $term -> slug;
            }
	
	<?php
3
$args = array(
4
    'tax_query' => array(
5
        array(
6
            'taxonomy' => 'people',
7
            'field'    => 'slug',
8
            'terms'    => 'bob',
9
            'operator' => 'IN'
10
        )
11
    )
12
);
13
$query = new WP_Query( $args );

	
	
	
	*/
	$i = 0;
	foreach ( $terms as $term ) {		
			if("hulu" == $term -> slug){
				continue;
			}else if($i == 0){
				$slug = "'".$term -> slug."'";
				$i++;
			} else if($i != 0){
				$slug .= ",'".$term -> slug."'";
				$i++;
			}
	}
		
	$array = explode(",", $slug);
	
	
			$arg = array (
				'post_status' => 'publish',
				'post_type' => 'movie',
				'numberposts' => 15,
				'orderby' => 'rand',
				'tax_query' => array(
					array(
						'taxonomy' => 'movie_genre',
						'field' => 'slug',
						'terms' => $array,
						'operator' => 'AND'
					)
				)	
			);
			
			$tax_posts = get_posts($arg ); if($tax_posts): 
	?>
        <ul id="mycarousel14" class="jcarousel-skin-tango">
			
			<?php foreach($tax_posts as $tax_post): 
			$thumbnail = get_the_post_thumbnail($tax_post->ID,"top-thumb",true);
			?>
				
                <li>
        		<span class="top-movie-thumb css-hover2">
                <a href="<?php echo get_permalink($tax_post->ID); ?>"><?php echo $thumbnail; ?></a>
                </span>
                <span class="top-movie-title">
                <a href="<?php echo get_permalink($tax_post->ID); ?>"><span><?php echo esc_html($tax_post->post_title); ?></span></a>
                </span>
                </li>
			<?php endforeach; ?>
		
        </ul>
        
	<?php endif; ?>
    </ul></div><!-- movie-genre-box end Similar  -->   
  <?php } ?>  

    
    </div>
    
<?php get_footer() ?>
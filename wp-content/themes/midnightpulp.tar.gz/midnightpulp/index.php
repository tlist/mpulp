<?php get_header() ?>

	<?php echo PfBase::getBlock('blocks'.DS.'slideshow_main.php', array('limit' => 4)) ?>

		<div class="breadcrumb">
			<ul>
		    	<li class="alone cls-home">
				<a href="javascript:;" class="active"><?php echo __('All') ?></a>
			</li>
		        <li class="alone cls-newsfeed">
				<a href="javascript:;"><?php echo __('Newsfeed') ?></a>
			</li>
			</li>
		        <li class="alone cls-movies">
				<a href="javascript:;"><?php echo __('Movies') ?></a>
			</li>
		    </ul> 
	
		</div> <!-- end breadcrumb -->

	<div class="main_content fresh">

		<div class="wrapper cls-content-home">
		 
		 <?php query_posts( array(
            'post_type' => array('movie','newsfeed'),
            'taxonomy' => array('movie_genre','newsfeed'),
            /*'term' => 'hulu',*/
            'posts_per_page' =>  24 
        )); ?>	
	     
        <?php if(have_posts()): ?>
        
        <?php while(have_posts()):the_post(); 
		
	  
		
		        $all_meta_data = amr_get_post_meta_all(get_the_ID());
            
            	$movie_year 			= $all_meta_data['movie_year'] ? ' ('. $all_meta_data['movie_year'] . ')' : '';
                $movie_duration 		= $all_meta_data['movie_duration'];
                $movie_featured 		= $all_meta_data['movie_featured'];
                $movie_plot				= $all_meta_data['movie_plot'];
                $movie_quotes			= $all_meta_data['movie_quotes'];
                $movie_embedded_video 	= $all_meta_data['movie_embedded_video'];
                $movie_hulu_video 		= $all_meta_data['movie_hulu_video'];
                $movie_amazon_link 		= $all_meta_data['movie_amazon_link'];
                $movie_thumb			= $all_meta_data['_thumbnail_id'];
    	
             	$newsfeed_year 			= $all_meta_data['newsfeed_year'] ? ' ('. $all_meta_data['newsfeed_year'] . ')' : '';
                $newsfeed_duration 		= $all_meta_data['newsfeed_duration'];
                $newsfeed_featured 		= $all_meta_data['newsfeed_featured'];
                $newsfeed_plot				= $all_meta_data['newsfeed_plot'];
                $newsfeed_quotes			= $all_meta_data['newsfeed_quotes'];
                $newsfeed_embedded_video 	= $all_meta_data['newsfeed_embedded_video'];
                $newsfeed_hulu_video 		= $all_meta_data['newsfeed_hulu_video'];
                $newsfeed_amazon_link 		= $all_meta_data['newsfeed_amazon_link'];
                $newsfeed_thumb			= $all_meta_data['_thumbnail_id'];
		        $newsfeed_meta_descrip  = $all_meta_data['_yoast_wpseo_metadesc'];    
		        
		        $strAuthorNiceName	=	get_the_author_meta('user_nicename', $post->post_author);
		
		
	         	$date = strtotime($post->post_date);
	        	$formatted_date = date('m/d/Y', $date);
		
	    ?>	
		
	
        
    	<li class="tile <?php echo $post->post_type; ?>">
        
		<span class="tile-type">
		<?php echo $post->post_type; ?>
		</span>
		
		<span class="tile-date">
		<?php echo $formatted_date;?>
        </span>
		
		<span class="tile-movie-thumb css-tile2">
        <a href="<?php the_permalink() ?>"><?php the_post_thumbnail('top-thumb'); ?></a>
        </span>
	    <div class="tile-movie-data-wrap">
	    <a href="<?php the_permalink() ?>">
			<span class="tile-movie-title">
	        <!--<a href="<?php the_permalink() ?>"><?php if(mb_strlen($post->post_title)>25) { $title= mb_substr($post->post_title,0,25) ; echo $title."..." ; } else {echo $post->post_title;}?></a>-->
	        <!--<a href="<?php the_permalink() ?>">-->
	        	<?php echo $post->post_title; ?>
	        <!--</a>-->
	        
	        </span>
	        

	        
			<span class="tile-description">
			    <!--<?php if(mb_strlen($movie_plot)>100) {$plot= mb_substr($movie_plot,0,100); echo $plot."...";} else { echo $movie_plot; } ?>-->
				<span class="movie-plot"><?php echo $movie_plot;  ?></span>
				<span class="seo-descrip"><?php echo $newsfeed_meta_descrip;?></span>
			</span>
		

			
			<span class="tile-author">
			<?php echo $strAuthorNiceName; ?>
			</span>
	
		    <span class="tile-readmore">
			<!--<a href="<?php the_permalink() ?>">-->
				WATCH
			<!--</a>-->
			</span>
		</a>
		</div>
		</li>	
        
         
        <?php endwhile; else: ?>
         
        <p>Sorry No item</p>
         
        <?php endif; ?>
        
      </div>  <!-- end cls-content-home wrapper -->
        
      
        <?php wp_reset_query(); ?>
		
         <script type="text/javascript">
			var waitForFinalEvent = (function () {
			  var timers = {};
			  return function (callback, ms, uniqueId) {
			    if (!uniqueId) {
			      uniqueId = "Don't call this twice without a uniqueId";
			    }
			    if (timers[uniqueId]) {
			      clearTimeout (timers[uniqueId]);
			    }
			    timers[uniqueId] = setTimeout(callback, ms);
			  };
			})();
			
			var tileFix = function (visClass){
				
				jQuery("li.tile").css('clear', 'none').css('background', 'none');
				
				var strTmp = ".tile";
				if (visClass !== ".all") {
					if (visClass == ".movies") {visClass = ".movie"}
					strTmp += visClass
				}

				var across = null,
				    targets = jQuery(strTmp);

	    		if (jQuery(window).width() >= 1200) { across = 4; }    
	    		if (jQuery(window).width() < 1200 && jQuery(window).width() >= 910) { across = 3; }    
	    		if (jQuery(window).width() < 910 && jQuery(window).width() >= 720) { across = 3; }    
	    		if (jQuery(window).width() < 720 && jQuery(window).width() >= 520) { across = 2; }
	    		
	    		var count = 0;
	    		
	    		jQuery(targets).each(function(count){
	    			if (count % across === 0 ) {jQuery(this).css('clear', 'left');}
	    			count ++
	    		})

	    		return true;
			}
			
	    	jQuery('.breadcrumb li a').click( function(){
	    		var wrapper = jQuery('.main_content');
	    	
	    		if (jQuery(this).hasClass('active')) return true;
	    		else {

		    		jQuery('.breadcrumb li a').removeClass('active');
		    		wrapper.hide();
		    		
		    		jQuery(this).addClass('active');
		    		var strTmp = jQuery(this).parent().attr('class');
		    		
		    		if (strTmp.indexOf('home') >= 0) {wrapper.attr('class', 'main_content'); tileFix('.all'); }
		    		else if (strTmp.indexOf('movie') >=0) { wrapper.attr('class', 'main_content show-movie'); tileFix('.movie'); }
		    		else if (strTmp.indexOf('newsfeed') >=0) {wrapper.attr('class', 'main_content show-newsfeed'); tileFix('.newsfeed'); }
		    		else console.log ("*shrug*");
		    		
					wrapper.fadeIn();
				}

	    	});
	    	
			jQuery(document).ready( function(){
	    		jQuery('.cls-content-newsfeed').hide();
				jQuery('.cls-content-movie').hide();
	    	});
	    	
			jQuery(window).resize(function () {
				waitForFinalEvent(function(){
					var activeCrumb = jQuery(".breadcrumb ul li").find('a.active').html().toLowerCase();
	    			tileFix("." + activeCrumb);
				}, 500, "tileFix");
			});

</script>
</div>

<?php get_footer() ?>


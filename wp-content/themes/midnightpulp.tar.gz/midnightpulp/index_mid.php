
<!DOCTYPE html>
<!--[if IE 8]> 				 <html class="no-js lt-ie9" lang="en" > <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="en" > <!--<![endif]-->

<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width">
  <title>Asian Crush Tiles</title>
  
  <link href='<?php echo PfBase::app()->themeUrl; ?>/_css/tile.css' rel='stylesheet' type='text/css' />
  <script src="<?php echo PfBase::app()->themeUrl; ?>/_js/vendor/custom.modernizer.js" type="text/javascript"></script>

</head>
<body>
<div id="header">&nbsp;</div>

<div id="main">

	<div id="tabrow">
		<div class="nav selected" id="all">ALL</div>
		<div class="nav" id="nav">NEWSFEED</div>
		<div class="nav" id="nav">COLUMNS</div>
		<div class="nav" id="nav">MOVIES</div>
	</div>

	<div class="clearfix" id="tilewrapper">


		<br/>
		<div id="that_one_line_at_the_top">
			&nbsp;<hr/>&nbsp;
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/54ef48cf69702d070b807a00/1424967886/original.png?1424967886" alt="Zardoz"></div>
			<div class="headline">A Film Bizarre Beyond Belief: Praise Zardoz!</div>
			<div class="text">Movies like Zardoz encounter a specific pitfall: they appear so weird on the surface that digging any further seems fruitless. This is a BIG mistake. We've all seen the "Sean Connery in a red diaper" photos, and have probably even missed Zardoz references in many of our favorite shows, but too few are aware of the insanity this movie hides at its core.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/54e3643b69702d070be21e01/1424188472/original.png?1424188472" alt="Shrooms"></div>
			<div class="headline">Killer Mushrooms on the Dark Side of the Sun</div>
			<div class="text">John Zorn's Dark Side of the Sun film series continues at the Japan Society with a screening of Matango (aka Attack of the Killer Mushrooms). A different kind of kaiju film from Godzilla creator Ishiro Honda, Matango (aka Attack of the Mushroom People) is a hybrid tale of survival, body, and monster horror with a deep sense of Twilight Zone irony.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/54d52be769702d04ca156500/1423256550/original.png?1423256550" alt="Romero"></div>
			<div class="headline">Of Hungry Cannibals &amp; Murderous Children: George A. Romero</div>
			<div class="text">An icon of independent horror cinema, George A. Romero changed the genre forever in 1968, a Pittsburgh filmmaker who became a midnight movie icon. The DEAD series, MARTIN, and many more collectively make the legacy of a man who realized his gory, politically charged visions without compromise.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/54c9150169702d070cb27600/1422464256/original.png?1422464256" alt="Tim and Eric"></div>
			<div class="headline">How Tim and Eric Carved a Niche in Cathode Ray Hell</div>
			<div class="text">Love them or hate them, at some point in time Tim and Eric have probably made you queasy. With their latest series, Tim &amp; Eric's Bedtime Stories, having wrapped its limited run, I look back at some of their other projects and attempt to explain the appeal of the divisive comedians.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/549329a269702d47f1701200/1418930593/original.png?1418930593" alt="Casanova"></div>
			<div class="headline">Facebook Pulp: The Cult of CHARLIE CASANOVA</div>
			<div class="text">CHARLIE CASANOVA was assembled on Facebook. Learn the backstory of this chilling slice of Midnight Pulp. A 2009 Facebook post from its director kicked off the production of the low-budget, gritty film. CASANOVA has drawn both praise controversy over its main character, a troubled man facing the darkness inside his soul.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/549484e069702d4340720200/1419019486/original.png?1419019486" alt="Pink Film"></div>
			<div class="headline">Sweetly Sleazy: Pink Film at NYC's Japan Society</div>
			<div class="text">Bondage, torture, and violence are all common themes in Japanese pink films, making this delightful story an even sweeter surprise than you might expect. As part of their series showcasing lesser-known gems of Japanese cinema, the Japan Society screened a rare 35mm print of Top Stripper, the 1982 pink film from Yoshimitsu Morita, who would achieve critical acclaim a year later for The Family Game.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/5491fcb769702d43403f0700/1418853558/original.png?1418853558" alt="Giallo Doll"></div>
			<div class="headline">Giallo’s Tangled Family Tree of Death and Debauchery</div>
			<div class="text">Discover the glorious, gory world of Giallo, one of the greatest genres in pulp film history. The influence of Giallo film in the '60s and '70s changed horror forever with their distinctive, stylish visual grammar and narrative tropes. Now, Midnight Pulp's DEEP SLEEP brings the tradition of Giallo into the 2010s.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/549329ee69702d4340021300/1418930668/original.png?1418930668" alt="Cronenberg"></div>
			<div class="headline">Long Live the Hollywood Flesh: Cronenberg Meets Tinseltown</div>
			<div class="text">Learn about the gory, brainy works of midnight maverick David Cronenberg, and his new film set in Hollywood. Cronenberg has made some of the most disturbing and cerebral pulp films ever known to midnight moviegoers. Now he's taking on Hollywood with MAPS TO THE STARS.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">John</div>
			</div>
		</div>

		<div class="tile">
			<div class="tag">Column</div>
			<div class="date">April 7, 2015</div>
			<div class="image"><img src="http://u.zype.com/53e8d7f869702d5b64010000/zobject_image/5494611669702d4340df0000/1419010325/original.png?1419010325" alt="Ghostface"></div>
			<div class="headline">Is The Scream Porn Parody a Legitimately Good Movie?</div>
			<div class="text">Vague memories of an adult film call me inexorably back towards its shores, begging answers to questions I thought I'd forgotten. Fortunately for me, Eli Cross, the director of Wetwork and hundreds of other adult and mainstream titles, joins me for an EXCLUSIVE interview to finally lay to rest these nagging uncertainties, and lay bare the story behind the making of his only porn parody.</div>
			<div class="tilefoot">
				&nbsp;
				<div class="readmore">Read More...</div>
				<div class="author">Crummy</div>
			</div>
		</div>

		
	</div>
</div>

<div id="footer">&nbsp;</div>

</body>
</html>

</div><!-- end container -->

<div id="footer">

	<div class="footer-sidebar">
        <?php dynamic_sidebar ('footer-1st');?>
	<?php dynamic_sidebar('footer-2nd'); ?>
	<!--	<?php dynamic_sidebar('footer-3rd'); ?>-->
	</div>
						    
						   
	<br clear="all" />
	<div id="footer-bar">

  		<div id="copyrightspan">
		    <img src="<?php echo PfBase::app()->themeUrl; ?>/_img/asiancrushlogo_icon.png" alt="<?php bloginfo('name'); ?>" />
			<p>&copy; <?php echo date('Y') ?> by Digital Media Rights. All Rights Reserved.</p>
		</div>

	</div>	
	
	<!--<div id="footer-bar">-->
	<!--	<div id="copyrightwrapper">-->
	<!--  		<img src="<?php echo PfBase::app()->themeUrl; ?>/_img/asiancrushlogo_final version.png" alt="<?php bloginfo('name'); ?>" />-->
	<!--		<div id="copyrightspan">-->
	<!--		    <?php-->
	<!--		          $numStartYear	=	2011;-->
	<!--		          $strYear	=	date('Y') > $numStartYear ? $numStartYear.' - '.date('Y') : $numStartYear;-->
	<!--		    ?>-->
	<!--		    <p>&copy; <?php echo $strYear ?> by Digital Media Rights. All Rights Reserved.</p>-->
	<!--		</div>-->
	<!--	</div>-->
	
</div>
				

        </div> <!-- end body_container -->
	</div>
	<!--	/Browser	-->
	
</div>
	<script src="<?php echo PfBase::app()->themeUrl; ?>/_js/buttonMaker.js" type="text/javascript"></script>
	<script src="<?php echo PfBase::app()->themeUrl; ?>/_js/vendor/owlcarousel/owl.carousel.min.js" type="text/javascript"></script>


	   <script type="text/javascript">
	       	jQuery(document).ready( function(){
				jQuery($).toggleTarget(
				["#mobile-menu-button", "#body_container", "mobile-menu-open", true],
				["#mobile-search-button", "#body_container", "mobile-search-open"]
				);
	    	})

	    </script>
	
	</body>
</html>

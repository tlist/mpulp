<?php get_header() ?>

	<?php echo PfBase::getBlock('blocks'.DS.'slideshow_main.php') ?>
	
	<div class="main_content">
		
		<?php echo PfBase::getBlock('blocks'.DS.'form_search_operator.php') ?>
		
		<?php echo PfBase::getBlock('blocks'.DS.'breadcrumb.php') ?>
		
		
        
		<?php echo PfBase::getBlock('blocks'.DS.'banner_728x90.php') ?>
	    
	</div>

<?php get_footer() ?>
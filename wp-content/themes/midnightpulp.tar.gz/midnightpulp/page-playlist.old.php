<?php
/**
 * Template Name: Page Playlist
 */

?>
 
<?php get_header() ?>
	<div class="main_content watchNow">
	
		    <?php 
		          query_posts( array(
            'post_type' => 'playlist',
            'posts_per_page' =>  -1 
        )); 
        
        ?>	
	     
        <?php if(have_posts()): ?>
        
        <?php
        $count = 1;
        while(have_posts()):the_post(); ?>
		 
		            <h1><?php echo get_the_title(); ?></h1>
 
                    
                <?php if ($posts) : ?>
               
                  <ul id="mycarousel<?php echo $count;  ?>" class="jcarousel-skin-tango">
       
                    <?php foreach($posts as $post) : ?>
                     
                        
                   <li>
                    <a href="<?php the_permalink(); ?>">
                    <span class="top-movie-thumb css-hover2">
                        <?php the_post_thumbnail('top-thumb');?>
                    </span>
                    <span class="top-movie-title">
                        <span><?php echo get_the_title($post->ID); ?></span>
                    </span>
                    </a>
                  </li>
    
               <?php endforeach; ?>
            
            </ul>
         
            <?php endif; ?>
        
            <?php $count++;?>
         
           <?php endwhile;?>
    
        <?php endif; ?>
    

	  

<?php get_footer() ?>
